Purpose:
For EDR-VGF-01 DAQ .DB3 files, after convert it to .csv files, the executable program can
convert it to a more readable format.

Make sure instrument_mapping_file.csv is located in dist/ and the index in it MUST match the DAQ .csv files. There should NOT be any duplicates, or missing index.

Run the .exe in dist/

- Michael Wu 2023-03-03